<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\ArtikelController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/dashboard', function () {
//     return view('dashboard');
// });

Route::get('/', [HomeController::class, 'home'])->middleware('guest');
Route::get('/home', [HomeController::class, 'home'])->middleware('guest');

Route::get('/dashboard', [DashboardController::class, 'dashboard'])->middleware('auth');

Route::get('/login', [LoginController::class, 'login'])->name('login')->middleware('guest');
Route::post('/login', [LoginController::class, 'authenticate']);
Route::post('/logout', [LoginController::class, 'logout']);

Route::get('/register', [RegisterController::class, 'register'])->middleware('guest');
Route::post('/register', [RegisterController::class, 'store']);

Route::get('/course', [CourseController::class, 'course'])->middleware('auth');

Route::get('/artikel', [ArtikelController::class, 'Artikel'])->middleware('auth');

Route::get('/main', function () {
    return view('blog.layout.main');
});
Route::get('/about', function () {
    return view('about');
});