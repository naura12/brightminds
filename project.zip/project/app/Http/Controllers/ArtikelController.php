<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Artikel;

class ArtikelController extends Controller
{
    public function Artikel(){
        $artikels = Artikel::first();

        return view('blog.layout.artikel',['artikels' => $artikels]);
    }
}
