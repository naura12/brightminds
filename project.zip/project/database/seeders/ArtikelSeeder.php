<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ArtikelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('artikels')->insert([
            ['title' => 'Memahami Diagonal Bidang dan Diagonal Ruang pada Kubus dan Balok',
            'image' => 'gambar1.png',
            'desc' => "Sobat brightminds, kalo bicara soal bangun ruang kira-kira apa yang muncul di benak elo? Biasanya, bangun ruang yang pertama muncul adalah kubus atau balok karena keduanya adalah bangun ruang yang sering banget kita lihat sehari-hari.

            Nah, meskipun elo udah tau apa itu kubus dan balok, gue mau refresh sedikit nih tentang kedua bangun ruang tersebut.",
            'image2' => 'gambar2.png',
            'desc2' => "Kubus adalah ruang yang berbatas enam bidang persegi. Kubus terdiri atas 6 bidang, 12 rusuk, 8 titik sudut, dan 3 diagonal. Sementara itu, balok adalah ruang yang bidangnya berupa empat persegi panjang. Balok terdiri atas 6 bidang, 12 rusuk, 8 titik sudut, dan 3 diagonal.

            Loh? Apa bedanya sama kubus?
            
            Kata kuncinya, kubus itu terdiri atas persegi sementara balok terdiri atas persegi panjang dan persegi. Panjang, lebar, dan tinggi pada kubus memiliki nilai yang sama, sementara pada balok nilainya nggak sama.
            
            Tapi sebagai bangun ruang, kubus dan balok sama-sama punya unsur diagonal. Diagonal tersebut adalah diagonal bidang, diagonal ruang, dan bidang diagonal.",
            ],
        ]);
    }
}
