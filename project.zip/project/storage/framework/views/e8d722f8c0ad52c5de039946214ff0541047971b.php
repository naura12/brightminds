<div class="w-100 py-1 text-center text-light fs-5 position-absolute bottom-0" style="background-color: #002E5C">
   <div>
    <style>
        .warna-orange {
            color: #d5581f;

        }
    </style>

   </div>
    <span><b>bright</b></span><span class="warna-orange"><b>minds</b></span>
    <h5>Bright Minds, Shaping Tomorrow's Brilliance</h5>
    <h6>Home | Course | About Us</h6>
    <h6>(+62) 81172037465 | brightminds@gmail.com | @bright_minds</h6>
</div><?php /**PATH C:\Users\Anthonny\Documents\Kuliah\Semester 5\Web Programming\project\resources\views/includes/footer.blade.php ENDPATH**/ ?>