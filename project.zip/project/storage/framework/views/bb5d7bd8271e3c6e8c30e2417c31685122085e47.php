<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <title>Login Page</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    <?php echo $__env->make('includes.bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <style>
        body{
            background:url(background.png);
        }
    </style>
</head>
<body>
    <div class="background">
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
              <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(session()->has('loginError')): ?>
            <div class="alert alert-danger" role="alert">
              <?php echo e(session('loginError')); ?>

            </div>
            <?php endif; ?>
        <div class="login-container" >
            <div class="form-container">
                <h1>Login</h1>
                <h2>Hey, welcome back!</h2>
                <p>Let's start your activity, enjoy!</p>
                <form action="/login" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group"> 
                        <input type="email" id="email" name="email" placeholder="email" required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="password" id="password" name="password" placeholder="password" required>
                    </div>
                    <div class="form-group" href="#">
                        <button type="submit">Login</button>
                    </div>
                    <div class="signup-link">
                        <a href="/register">Don't have an account?</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Anthonny\Documents\Kuliah\Semester 5\Web Programming\project\resources\views/login.blade.php ENDPATH**/ ?>