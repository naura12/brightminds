<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('blog')); ?>/assets/Brightminds (6).png" />
    <link rel="stylesheet" href="artikel.css"></link>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <?php echo $__env->make('includes.navbar1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <button type="button" class="btn btn-outline-light course-color"><span><a href="/main">Back</a></span></button>
    <button type="button" class="btn btn-outline-light course-color"><span><a href="/dashboard">Home</a></span></button>
    <button type="button" class="btn btn-outline-light course-color"><span><a href="/course">Courses</a></span></button> -->
    <h1><?php echo e($artikels->title); ?></h1>
    <img class="image" src="<?php echo e($artikels->image); ?>" alt="gambarArtikel" />
    <div class="paragraf">
        <p><?php echo e($artikels->desc); ?></p>
    </div>
    <img class="image" src="<?php echo e($artikels->image2); ?>" alt="gambarArtikel" />
    <div class="paragraf">
        <p><?php echo e($artikels->desc2); ?></p>
    </div>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\Anthonny\Documents\Kuliah\Semester 5\Web Programming\project\resources\views/blog/layout/artikel.blade.php ENDPATH**/ ?>