<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo e(config('app.name')); ?></title>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('blog')); ?>/assets/Brightminds (6).png" />
        <link href="<?php echo e(asset('blog')); ?>/css/styles.css" rel="stylesheet" />
        <link href="main.css" rel="stylesheet" />
        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600;700&display=swap" rel="stylesheet">
    </head>
    <body>
    <!-- <button type="button" class="btn btn-outline-light course-color"><span><a href="/dashboard">Home</a></span></button>
    <button type="button" class="btn btn-outline-light course-color"><span><a href="/course">Courses</a></span></button> -->
           
    <?php echo $__env->make('includes.navbar1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="container">
                <div class="text-center my-5">
                    <h1 class="fw-bolder">Math</h1>
                </div>
            </div>
        <div class="container">
            <div class="row">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card mb-4">
                                <a href="artikel"><img class="card-img-top" src="/blog/assets/1.png" alt="cover" /></a>
                                <div class="card-body">
                                    <div class="small text-muted">January 1, 2023</div>
                                    <h2 class="card-title h4">Memahami Diagonal Bidang dan Diagonal Ruang pada Kubus dan Balok</h2>
                                    <p class="card-text">Sobat brightminds, kalo bicara soal bangun ruang kira-kira apa yang muncul di benak elo? Biasanya, bangun ruang yang pertama muncul adalah kubus atau balok karena keduanya adalah bangun ruang yang sering banget kita lihat sehari-hari.</p>
                                </div>
                            </div>
                            <div class="card mb-4">
                                <a href="#"><img class="card-img-top" src="/blog/assets/5.png" alt="cover" /></a>
                                <div class="card-body">
                                    <div class="small text-muted">January 1, 2023</div>
                                    <h2 class="card-title h4">Post Title</h2>
                                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">

                            <div class="card mb-4">
                                <a href="#!"><img class="card-img-top" src="/blog/assets/2.png" alt="cover" /></a>
                                <div class="card-body">
                                    <div class="small text-muted">January 1, 2023</div>
                                    <h2 class="card-title h4">Post Title</h2>
                                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla.</p>
                                </div>
                            </div>

                            <div class="card mb-4">
                                <a href="#!"><img class="card-img-top" src="/blog/assets/6.png" alt="cover" /></a>
                                <div class="card-body">
                                    <div class="small text-muted">January 1, 2023</div>
                                    <h2 class="card-title h4">Post Title</h2>
                                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla? Quos cum ex quis soluta, a laboriosam.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                 
                            <div class="card mb-4">
                                <a href="#!"><img class="card-img-top" src="/blog/assets/3.png" alt="cover" /></a>
                                <div class="card-body">
                                    <div class="small text-muted">January 1, 2023</div>
                                    <h2 class="card-title h4">Post Title</h2>
                                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla.</p>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <a href="#!"><img class="card-img-top" src="/blog/assets/7.png" alt="cover" /></a>
                                <div class="card-body">
                                    <div class="small text-muted">January 1, 2023</div>
                                    <h2 class="card-title h4">Post Title</h2>
                                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla? Quos cum ex quis soluta, a laboriosam.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                          
                            <div class="card mb-4">
                                <a href="#!"><img class="card-img-top" src="/blog/assets/4.png" alt="cover" /></a>
                                <div class="card-body">
                                    <div class="small text-muted">January 1, 2023</div>
                                    <h2 class="card-title h4">Post Title</h2>
                                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla.</p>
                                </div>
                            </div>
                           
                            <div class="card mb-4">
                                <a href="#!"><img class="card-img-top" src="/blog/assets/8.png" alt="cover" /></a>
                                <div class="card-body">
                                    <div class="small text-muted">January 1, 2023</div>
                                    <h2 class="card-title h4">Post Title</h2>
                                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla? Quos cum ex quis soluta, a laboriosam.</p>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <!-- Footer-->
        <!-- <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer> -->
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?php echo e(asset('blog')); ?>/js/scripts.js"></script>
    </body>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH C:\Users\Anthonny\Documents\Kuliah\Semester 5\Web Programming\project\resources\views/blog/layout/main.blade.php ENDPATH**/ ?>