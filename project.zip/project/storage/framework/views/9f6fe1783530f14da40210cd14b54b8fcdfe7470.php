<style>
    nav{
        background-color: #002e5c;
    }
    a{
    text-decoration: none;
}

.names{
    font-size: 30px;
    font-weight: bold;
}

.colorone{
    color: #D5581F;
}

.navlist{
    display: flex;
    padding-right: 4rem;
}

.navlist a{
    font-size: 20px;
    font-weight: bold;
    color: #F6EAD4;
    margin: 0 25px;
    transition: all ease .4s;
}

.navlist a:hover{
    color: #D5581F;
}

.btn{
    border-radius: 3rem;
    padding: 8px;
}

.btn:hover{
    transition: all ease .5s;
    background-color: #D5581F;
    border: transparent;
}

.login{
    padding: 2rem;
}

section{
    padding: 0 15%;
}
</style>
<nav>
            <?php if(auth()->guard()->check()): ?>
            <a href="/dashboard" class="names" style="color : #F6EAD4;">bright<span class="colorone">minds</span></a>
            <?php else: ?>
            <a href="/home" class="names" style="color : #F6EAD4;">bright<span class="colorone">minds</span></a>
            <?php endif; ?>
            <ul class="navlist">
                <?php if(auth()->guard()->check()): ?>
                <li><a href="/dashboard">Home</a></li>
                <?php else: ?>
                <li><a href="/home">Home</a></li>
                <?php endif; ?>
                <li><a href="/course">Course</a></li>
                <li><a href="/about">About Us</a></li>
            </ul>
            <div>
                <?php if(auth()->guard()->check()): ?>
                <form action="/logout" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-light"><span class="login">Logout</span></button>
                </form>
                <?php else: ?>
                <button type="button" class="btn btn-outline-light"><span class="login"><a href="/dashboard">Login</a></span></button>
                <?php endif; ?>
            </div>
</nav>



<?php /**PATH C:\Users\Anthonny\Documents\Kuliah\Semester 5\Web Programming\project\resources\views/includes/navbar1.blade.php ENDPATH**/ ?>