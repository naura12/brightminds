<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Course</title>
    @include('includes.bootstrap')
</head>

<style>
        .card {
            width: 8rem;
            background-color: darkblue;
            margin: 0 3rem;
        }
        .kartu-container {
            display: flex;
        }
        .kartu-container-dengan-jarak {
            display: flex;
            margin-top: 1rem;
        }
        .box-shadow {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        header{
        position: fixed;
        top: 0;
        right: 0;
        width: 100%;
        z-index: 1000;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 32px 2%;
        transition: all ease .45s;
        list-style: none;
        }

        a{
        text-decoration: none;
        }

        .names{
        font-size: 30px;
        font-weight: bold;
        }

        .colorone{
        color: #D5581F;
        }

        .navlist{
        display: flex;
        padding-right: 4rem;
        }

        .navlist a{
        font-size: 20px;
        font-weight: bold;
        color: #F6EAD4;
        margin: 0 25px;
        transition: all ease .4s;
        }

        .navlist a:hover{
        color: #D5581F;
        }

        .btn{
        border-radius: 3rem;
        padding: 8px;
        }

        .btn:hover{
        transition: all ease .5s;
        background-color: #D5581F;
        border: transparent;
        }

        .login{
        padding: 2rem;
        }
    </style>

<body style="background-color: oldlace;">
@include('includes.navbar') 

<div class="d-flex justify-content-center align-items-center flex-column m-4 box-shadow" style="padding: 80px 2%;">

    <div class="d-flex me-1">
    <div class="card" style="width: 8rem; background-color: #002E5C;">
        <img src="Math.jpg" class="card-img-top" alt="...">
         <div class="card-body">
        <h5 style="color: snow;">Maths</h5>
        <button class="btn" style="background-color: darkorange; color: snow;" type="submit"><b><a href="/main">Start Course</a></b></button>
        </div>
    </div>

    <div class="card" style="width: 8rem; background-color: #002E5C;">
        <img src="Science.jpg" class="card-img-top" alt="...">
         <div class="card-body">
        <h5 style="color: snow">Science</h5>
        <button class="btn" style="background-color: darkorange; color: snow;" type="submit"><b><a href="/main">Start Course</a></b></button>
        </div>
    </div>

    <div class="card" style="width: 8rem; background-color: #002E5C;">
        <img src="English.jpg" class="card-img-top" alt="...">
         <div class="card-body">
        <h5 style="color: snow;">English</h5>
        <button class="btn" style="background-color: darkorange; color: snow;" type="submit"><b><a href="/main">Start Course</a></b></button>
        </div>
    </div>
    
    <div class="card" style="width: 8rem; background-color: #002E5C;">
        <img src="ArtCulture.jpg" class="card-img-top" alt="...">
         <div class="card-body">
        <h5 style="color: snow;">Culture</h5>
        <button class="btn" style="background-color: darkorange; color: snow;" type="submit"><b><a href="/main">Start Course</a></b></button>
        </div>
    </div>

</div>

<div class="d-flex justify-content-center align-items-center flex-column m-4 box-shadow">

    <div class="d-flex me-1">
        <div class="card" style="width: 8rem; background-color: #002E5C;">
            <img src="Indonesian.jpg" class="card-img-top" alt="...">
            <div class="card-body">
            <h5 style="color: snow;">Indonesia</h5>
            <button class="btn" style="background-color: darkorange; color: snow;" type="submit"><b><a href="/main">Start Course</a></b></button>
        </div>
    </div>

    <div class="card" style="width: 8rem; background-color: #002E5C;">
        <img src="Social.jpg" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 style="color: snow">Social</h5>
            <button class="btn" style="background-color: darkorange; color: snow;" type="submit"><b><a href="/main">Start Course</a></b></button>
        </div>
    </div>

    <div class="card" style="width: 8rem; background-color: #002E5C;">
        <img src="Computer.jpg" class="card-img-top" alt="...">
         <div class="card-body">
            <h5 style="color: snow;">Computer</h5>
            <button class="btn" style="background-color: darkorange; color: snow;" type="submit"><b><a href="/main">Start Course</a></b></button>
        </div>
    </div>

</div>

</div>

    @include('includes.footer')
</body>
</html>