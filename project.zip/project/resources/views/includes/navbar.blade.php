<style>
    header{
        background-color: #002e5c;
    }
</style>
<header>
            @auth
            <a href="/dashboard" class="names" style="color : #F6EAD4;">bright<span class="colorone">minds</span></a>
            @else
            <a href="/home" class="names" style="color : #F6EAD4;">bright<span class="colorone">minds</span></a>
            @endauth
            <ul class="navlist">
                @auth
                <li><a href="/dashboard">Home</a></li>
                @else
                <li><a href="/home">Home</a></li>
                @endauth
                <li><a href="/course">Course</a></li>
                <li><a href="/about">About Us</a></li>
            </ul>
            <div>
                @auth
                <form action="/logout" method="post">
                    @csrf
                    <button type="submit" class="btn btn-outline-light"><span class="login">Logout</span></button>
                </form>
                @else
                <button type="button" class="btn btn-outline-light"><span class="login"><a href="/dashboard">Login</a></span></button>
                @endauth
            </div>
</header>



