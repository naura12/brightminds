<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <title>Login Page</title>
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
    @include('includes.bootstrap')
   <style>
        body{
            background:url(background.png);
        }
    </style>
</head>
<body>
    <div class="background">
            @if(session()->has('success'))
            <div class="alert alert-success" role="alert">
              {{session('success')}}
            </div>
            @endif
            @if(session()->has('loginError'))
            <div class="alert alert-danger" role="alert">
              {{session('loginError')}}
            </div>
            @endif
        <div class="login-container" >
            <div class="form-container">
                <h1>Login</h1>
                <h2>Hey, welcome back!</h2>
                <p>Let's start your activity, enjoy!</p>
                <form action="/login" method="post">
                    @csrf
                    <div class="form-group"> 
                        <input type="email" id="email" name="email" placeholder="email" required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="password" id="password" name="password" placeholder="password" required>
                    </div>
                    <div class="form-group" href="#">
                        <button type="submit">Login</button>
                    </div>
                    <div class="signup-link">
                        <a href="/register">Don't have an account?</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
