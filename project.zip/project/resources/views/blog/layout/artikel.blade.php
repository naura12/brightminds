<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('blog') }}/assets/Brightminds (6).png" />
    <link rel="stylesheet" href="artikel.css"></link>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600;700&display=swap" rel="stylesheet">
</head>
<body>
    @include('includes.navbar1')
    <!-- <button type="button" class="btn btn-outline-light course-color"><span><a href="/main">Back</a></span></button>
    <button type="button" class="btn btn-outline-light course-color"><span><a href="/dashboard">Home</a></span></button>
    <button type="button" class="btn btn-outline-light course-color"><span><a href="/course">Courses</a></span></button> -->
    <h1>{{$artikels->title}}</h1>
    <img class="image" src="{{$artikels->image}}" alt="gambarArtikel" />
    <div class="paragraf">
        <p>{{$artikels->desc}}</p>
    </div>
    <img class="image" src="{{$artikels->image2}}" alt="gambarArtikel" />
    <div class="paragraf">
        <p>{{$artikels->desc2}}</p>
    </div>
    @include('includes.footer')
</body>
</html>